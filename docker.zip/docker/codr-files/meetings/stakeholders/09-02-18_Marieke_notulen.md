op zoek naar manier om studenten (in het begin) voor mensen die geen programeerervaring hebben: tijdens practicum aftekenen (hoe sneller) en meer feedback kunnen krijgen van wat er zou moeten gebeuren (vb de three way lamp waar veel mensen die niet kunnen programeren op vast zitten). Vooral hier automatisering voor.

Ook in de tool voor mensen die heel makkelijk het programmeren afgaat nog extra challenges.

Belangrijk dat studenten onder elkaar kunnen helpen met vragen over code.
Als administratie in de tool zit is security een belangrijk punt. (Kunnen niet bruteforcen bv bij de cijfers).

Moet overzichtelijk blijven, structuur om te groeperen. (bijvoorbeeld grote groepen onderverdelen). 

Kunnen zien wie er nog meer naar dezelfde code of post aan het kijken zijn.

Aftekenen moet fysiek blijven! moeten personen in de studie blijven om te helpen (contacturen).


