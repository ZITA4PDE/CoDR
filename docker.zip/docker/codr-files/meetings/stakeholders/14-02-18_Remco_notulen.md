# Onderzoek

Was meer gericht op automatische feedback.

Misschien meerdere systemen voor verschillend niveau programmeurs.

Rechten systeem implementeren kan best veel werk zijn.

Student assistenten van create gebruiken ons systeem waarschijnlijk heel anders dan dat CS TA's dat zouden doen.

Houd de scope klein, richt je op code review. 

**Maar als je het extensible kan maken is dat erg preferabel.**

Dus denk goed na over de structuur van je applicatie.

# Gerrit

Zou in scope kunnen zijn.


