- Paper over feedback op code, kan hij opsturen (is opgestuurd).
- Denk goed na over niveau van de feedback (als automatisch systeem).
  * Sommige mensen hebben al moeite met syntax (code die niet compileert), terwijl veel tools er van uit gaan dat mensen syntax kennen.
- Kijk (vroeg) naar mogelijke automatie van feedback, want daar zit de bottleneck
  * Veel tijdwinst als het automatisch kan, er zijn tools die daarbij zouden kunnen helpen ( -> buiten scope van ons project? ).
- Ze gebruiken (waarschijnlijk) Processing bij create, maar is eigenlijk gewoon Java -> navragen bij Ansgar voor de zekerheid.
- Vergelijk met "Canvas speedgrading".
  * Gemaakt voor tekstdocumenten, niet code. Wij zouden dat juist kunnen verbeteren, eventueel plugin voor Canvas?
  * Alles op een plek, studentsassistenten kunnen het dan snel nakijken.
  * Integratie van alle systemen zou het best zijn.
  * Canvas heeft een systeem voor plugins waar we eventueel naar zouden kunnen kijken met mensen van ICTS.
  * Probeer in ieder geval centrale logingegevens te gebruiken als het mogelijk is.
