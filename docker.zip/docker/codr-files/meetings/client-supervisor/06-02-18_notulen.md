Notulen 06-02-18

Code review

feedback op programma's van studenten door reviewer op alle mogelijke tijden. Fatsounlijke discussies mogelijk maken tussen SA en studenten.

er zijn bestaande systemen maar 

mooi: regels/block highlighten en daar ook discusseren/topic maken

SA en profs moeten andere rechten hebben dan studenten

group assignments supporten

afschermen van assignments(alleen toegang voor bepaalde studenten)


commentaar taggen met keywords twitter idee, dit later kunnen ophalen tijdens nakijken.

Moderation mogelijk

student moet ook commentaar kunnen leveren en deelnemen aan topics

setting of commentaar zichtbaar is/niet

meekijken tijdens development

vorig jaar groepje invloed tools: belangrijk dat alles draaiende kan blijven als het is opgeleverd

autolab, automatisch nakijken, niet zo interessant wel handig om even naar te kijken, gerrit ook handig

testinator gemaakt vorig jaar, ui niet goed genoeg, niet genoeg support voor meerdere repo’s, wordt doorgestuurd naar ons. Niet goed getest, teveel bugs.

discussies op stackoverflow met up/downvotes etc feedback terug naar SA

closen/openen van discussies

overzicht voor SA van discussies

externe tools feedback er in, zijn in essentie SA. Hoeft niet in de basis.

Mogelijkheid voor snippets en daar vragen over stellen.

Voor java

Basis: SA → inline comments en daar discussies over hebben. Studenten in groepjes/alleen werken. Version control is niet direct nodig voor de basis. 

Komt een doodle voor een vaste afspraak

voorkeur voor woensdag

belangrijke punten assessment:
- uitgewerkte user stories (docent → overzicht alles wat gaande is, student → wil code uploaden)
- overzicht 
- unit tests
- scenario doorlopen op het einde om te kijken of het goed werkt.
- useability is het belangrijkst!!
- attentie voor details, geen sloppy foutjes waar mensen zich aan gaan storen.

Integreren met gitlab is het handigst

afspraken worden gemaakt met marieke louis en remco

mogelijke mooie toevoeging automatisch nakijken

belangrijk dat er een product owner is die de kwaliteit bewaakt.

User stories goed uitwerken en daadwerkelijk echt uitvoeren

