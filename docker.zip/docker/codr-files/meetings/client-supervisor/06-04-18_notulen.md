"laatste comment van student, moderator en sa"
open en close van een commentthread status beantwoord


- plus knop bij project in exercise
- naam voor projectgroep
- lijst van verschillende projecten in projectgroep
- selecteren met highlighten
- zelf namen kiezen
- tijdelijke rechten
- download knop voor moderators/student assistenten
- tag systeem voor visibility level op comments
- functionaliteit voor projecten 
- announcements 
- summary van het project
- in profile commentaarregels --> go to file (naam)
- in profile de replies van de comments
- in profile ordering van de comments

Kleurcodes voor een moderator.
Upload deletes wrong.
Hoeveelheid comments.
Aan het typen.
Als invisible comments, feedback aan user.
postTemplate fail.
Ordering comments.

