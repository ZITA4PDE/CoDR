Opdrachten waar dan projecten onder hangen.

Voornamelijk voor gebruik tijdens tutorials (aftekenen).

2 aspecten:

- Projecten onder opdrachten
- Stack overflow achtige discussie. (Could)

Per vak een aantal opdrachten die alle studenten in het vak kunnen zien.
Studenten zijn gekoppeld aan een vak.

Studenten programmeren op hun eigen laptop, op moment dat ze feedback willen of er moet feedback gegeven worden dan uploaden/syncen ze hun code.

Satus pagina:

- iedereen: opdrachten en zijn eigen discussies.

Could: eindoordeel van opdracht.

Moderatie per opdracht.
Moderatie templates (should).

- peer review
- wordt nagekeken

Status pagina en commentaar vak zijn het belangrijkts.

user story voor rechten wijzigen als moderator.

Modereren vooral vooraf.

Voor aftekenmoment moet de code geupload zijn.

Datum wanneer het geupload.

Misschien ook einddatum van opdracht.

admin pagina:

- Vakken maken
- Studenten toekennen.
- Nieuwe opdrachten definiëren.
