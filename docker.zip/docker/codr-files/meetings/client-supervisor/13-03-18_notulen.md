#project plan
semantic syntactic line file verduidelijken

user --> moderator in should add people to project

#front end
nog wat extra handige knoppen, kijk naar layouts van andere applicaties

#login
hoeft niet canvas zolang utwente login werkt
