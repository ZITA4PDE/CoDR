# Commentaar project proposal.

## 2

-second
+first

blackboard en slack allebei gebruikt, maar beide ongeschikt.

file based/line based regel moet duidelijker, commentaar op file-niveau is ook belangrijk.

## 3

Test plan, ook uitkomsten met gebruikers.

Acceptance testing/beta testing, met student assistenten. Opnemen in test plan.

# Extra requirements

Would: peer review.
Could: Per project, een dashboard met commentaar per project. Filter functionality, bijv. op tags.

Approval system duidelijker in requirements.
