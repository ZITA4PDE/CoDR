Inloggegevens canvas worden opgestuurd.
university-twente.acme.instructure.com

user: admin
pass: Drienerloolaan5

Tenzij tegenbericht is projectproposal akkoord.

##database schema

comment, column approved.

##usability test

###Assessement
powerpoint assessement 1-3 and last.
