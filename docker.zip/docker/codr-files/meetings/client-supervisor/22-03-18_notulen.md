Notulen 22-03-18

# Comments
Na inklappen van comments moet highlighting met een box goed genoeg zijn.

Bevestigings pop-up wanneer een comment gedelete moet worden.
Evt commentaar met de reden dat een comment is verwijderd.

Mogelijkheid om bij het verwijderen van een comment de content op deleted zetten ipv de comment en de children helemaal te verwijderen.

Geen opmerkingen op het project proposal.

het commentaar moet eigenlijk wel ergens bewaard blijven

