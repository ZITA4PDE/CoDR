var socket = io();
socket.on('test', function(message) {console.log(message)});
