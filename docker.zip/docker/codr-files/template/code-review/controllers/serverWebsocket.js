var io;

module.exports = {
	init: function(server) {
		/**
		 * Create a Node.io object on the server object.
		 */

		io = require('socket.io')(server);
	},

	send: function(header, message) {
		io.sockets.emit(header, message);
	}
};

