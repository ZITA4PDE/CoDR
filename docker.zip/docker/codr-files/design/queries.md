# must
get all courses
get all exercises for course
get all comments for file
get all relevant comments for user homepage
create comment
create project
create course
create exercise
create rights template
edit comment
edit project
edit course
edit exercise
edit rights template
delete comment
delete project
delete course
delete exercise
delete rights template

# should
get all comments for course
get all projects for exercise
get all projects for user
get all comments for project
