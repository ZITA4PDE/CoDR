import ReactDOM from 'react-dom';
import React from 'react';
import {Sidebar} from './sidebar';

ReactDOM.render(<Sidebar/>, document.getElementById('sidebar'));
