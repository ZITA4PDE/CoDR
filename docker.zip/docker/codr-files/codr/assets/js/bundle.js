import '../stylesheets/style.scss';

import 'bootstrap';
import 'jquery';
import 'popper.js';