DROP FUNCTION IF EXISTS checkbit(rights bit, b integer);
CREATE FUNCTION checkbit(rights bit, b integer) RETURNS boolean AS $$
BEGIN
RETURN CASE WHEN (rights >> (b-1))::integer & 1 = 1 THEN TRUE ELSE FALSE END;
END
$$ LANGUAGE plpgsql;

DROP FUNCTION IF EXISTS projects_rights(uid integer);
CREATE FUNCTION projects_rights(uid integer) 
RETURNS TABLE(
id integer, 
exercise_id integer, 
author_id integer, 
projectgroup_id integer,
can_view boolean,
can_edit boolean,
can_create_comment boolean,
can_create_visible_comment boolean,
can_delete boolean) 
AS $$
SELECT p.id, p.exercise_id, p.author_id, p.projectgroup_id,  
checkbit(rights, 1) as can_view,
checkbit(rights, 2) as can_edit,
checkbit(rights, 3) as can_create_comment,
checkbit(rights, 4) as can_create_visible_comment,
checkbit(rights, 5) as can_delete
FROM
(SELECT p.*,  
    (CASE WHEN (SELECT (user_level = 0) FROM users WHERE users.id = uid) 
        THEN B'11111' 
        ELSE
            (CASE WHEN EXISTS (SELECT pu.user_id FROM projectgroup_users pu WHERE p.projectgroup_id = pu.projectgroup_id AND pu.user_id = uid) 
                THEN member 
                ELSE other 
            END)
    END) as rights
FROM
(SELECT p.*, 
cast(tc.project_right >> 5 as bit(5)) as other, 
tc.project_right::bit(5) as member
FROM 
projects p, 
exercises e,
courses c, 
modules m, 
module_users mu,
templates_content tc 
WHERE e.id = p.exercise_id 
AND c.id = e.course_id
AND m.id = c.module_id
AND mu.module_id = m.id
AND mu.user_id = uid
AND e.rights_template_id = tc.template_id
AND tc.group_id = mu.group_id) as p) as p
$$ LANGUAGE SQL;

DROP FUNCTION IF EXISTS comments_rights(uid integer);
CREATE FUNCTION comments_rights(uid integer) 
RETURNS TABLE(
id integer,
parent_id integer,
file_id integer,
line_range text,
content text,
author_id integer,
visible boolean,
"timestamp" bigint,
deleted boolean,
can_view boolean,
can_edit boolean,
can_delete boolean,
can_toggle_visibility boolean
)
AS $$
SELECT c.id, c.parent_id, c.file_id, 
c.line_range, c.content, c.author_id, c.visible,
c.timestamp, c.deleted,
checkbit(rights, 1) as can_view,
checkbit(rights, 2) as can_edit,
checkbit(rights, 3) as can_delete,
checkbit(rights, 4) as can_toggle_visibility
FROM
(SELECT c.*,  
    (CASE WHEN (SELECT (user_level = 0) FROM users WHERE users.id = uid) 
        THEN B'1111' 
        ELSE
            ( CASE WHEN c.author_id = uid THEN owner 
            ELSE (CASE WHEN EXISTS 
                (SELECT pu.user_id 
                    FROM projectgroup_users pu 
                    WHERE projectgroup_id = pu.projectgroup_id 
                    AND pu.user_id = uid) THEN member 
            ELSE other END) 
            END)
    END) as rights
FROM
(SELECT c.*, p.projectgroup_id,
cast(tc.comment_right >> 8 as bit(4)) as other, 
cast(tc.comment_right >> 4 as bit(4)) as member, 
tc.comment_right::bit(4) as owner
FROM 
comments c,
files f,
projects_rights(uid) p, 
exercises e,
courses co, 
modules m, 
module_users mu,
templates_content tc 
WHERE f.id = c.file_id
AND p.id = f.project_id
AND e.id = p.exercise_id 
AND co.id = e.course_id
AND m.id = co.module_id
AND mu.module_id = m.id
AND mu.user_id = uid
AND e.rights_template_id = tc.template_id
AND tc.group_id = mu.group_id) as c) as c
$$ LANGUAGE SQL;

DROP FUNCTION IF EXISTS modules_rights(uid integer);
CREATE FUNCTION modules_rights(uid integer) 
RETURNS TABLE(
id integer,
name text,
description text,
can_view boolean,
can_edit boolean
)
AS $$
SELECT id, name, description,
(CASE WHEN EXISTS (SELECT id FROM modules m, module_users mu WHERE mu.user_id = uid AND m.id = mu.module_id AND m.id=id) THEN true ELSE (CASE WHEN EXISTS (SELECT user_level = 0 FROM users WHERE id = uid) THEN true ELSE FALSE END) END) as can_view,
(CASE WHEN EXISTS (SELECT * FROM module_users WHERE user_id = uid AND module_id=id AND group_id = 3) THEN true ELSE false END) AS can_edit
FROM
modules
$$ LANGUAGE SQL;
